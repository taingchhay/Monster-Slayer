import React, { useState, useEffect } from "react";
import Entity from "./Entity";
import GameOver from "./GameOver";
import Log from "./Log";

// Helper functions
function getRandomValue(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

function createLogAttack(isPlayer, damage) {
  return {
    isPlayer: isPlayer,
    isDamage: true,
    text: ` takes ${damage} damages`,
  };
}

function createLogHeal(healing) {
  return {
    isPlayer: true,
    isDamage: false,
    text: ` heal ${healing} life points`,
  };
}

function Game() {
  // States
  const [playerHealth, setPlayerHealth] = useState(100);
  const [monsterHealth, setMonsterHealth] = useState(100);
  const [currentRound, setCurrentRound] = useState(0);
  const [winner, setWinner] = useState(null);
  const [logs, setLogs] = useState([]);

  // Computed values
  const specialAttackAvailable = currentRound % 3 === 0 && currentRound > 0;
  const gameOver = playerHealth <= 0 || monsterHealth <= 0;

  // Attack function
  const attackMonster = (isSpecialAttack = false) => {
    const damage = isSpecialAttack 
      ? getRandomValue(10, 25) 
      : getRandomValue(5, 12);
    
    setMonsterHealth(prev => Math.max(0, prev - damage));
    addLog(createLogAttack(true, damage));
    monsterAttack();
    setCurrentRound(prev => prev + 1);
  };

  // Monster attack function
  const monsterAttack = () => {
    const damage = getRandomValue(8, 15);
    setPlayerHealth(prev => Math.max(0, prev - damage));
    addLog(createLogAttack(false, damage));
  };

  // Heal function
  const healPlayer = () => {
    const healing = getRandomValue(8, 20);
    setPlayerHealth(prev => Math.min(100, prev + healing));
    addLog(createLogHeal(healing));
    monsterAttack();
    setCurrentRound(prev => prev + 1);
  };

  // Kill self function
  const killSelf = () => {
    setPlayerHealth(0);
    addLog({
      isPlayer: true,
      isDamage: true,
      text: " commits suicide"
    });
  };

  // Add log function
  const addLog = (logEntry) => {
    setLogs(prev => [logEntry, ...prev]);
  };

  // Check game over and determine winner
  useEffect(() => {
    if (gameOver) {
      if (monsterHealth <= 0 && playerHealth <= 0) {
        setWinner('draw');
      } else if (monsterHealth <= 0) {
        setWinner('player');
      } else if (playerHealth <= 0) {
        setWinner('monster');
      }
    }
  }, [monsterHealth, playerHealth]);

  // Restart game
  const restartGame = () => {
    setPlayerHealth(100);
    setMonsterHealth(100);
    setCurrentRound(0);
    setWinner(null);
    setLogs([]);
  };

  return (
    <>
      {winner && (
        <GameOver 
          title={
            winner === 'draw' 
              ? 'It\'s a Draw!' 
              : winner === 'player' 
                ? 'You Won!' 
                : 'You Lost!'
          } 
          restartGame={restartGame} 
        />
      )}

      <Entity health={monsterHealth} name="Monster" />
      <Entity health={playerHealth} name="Player" />

      {!winner && (
        <section id="controls">
          <button onClick={() => attackMonster()}>ATTACK</button>
          <button 
            onClick={() => attackMonster(true)} 
            disabled={!specialAttackAvailable}
          >
            SPECIAL !
          </button>
          <button onClick={healPlayer}>HEAL</button>
          <button onClick={killSelf}>KILL YOURSELF</button>
        </section>
      )}

      <Log logs={logs} />
    </>
  );
}

export default Game;